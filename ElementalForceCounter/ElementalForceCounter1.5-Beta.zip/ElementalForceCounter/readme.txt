Place all files in the folder "The Secret World\Data\Gui\Customized\Flash\ElementalForceCounter"

Left Click to reset Elemental Force
Shift Left Click to change palce
Shift Mouse wheel to resize
Right Click to toggle click to reset